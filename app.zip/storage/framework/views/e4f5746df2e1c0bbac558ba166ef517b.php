<?php $__env->startSection('content'); ?>
    <?php
        // Layar awal ditentukan server agar halaman landing tidak sempat tampil sebelum JS jalan.
        $staffViews = ['staff', 'dapur', 'kasir', 'display', 'login', 'riwayat', 'stok', 'keuangan', 'menu'];
        $customerFirst = ! in_array(request('view'), $staffViews, true);
    ?>
    
    <div id="customer-shell" <?php if (! ($customerFirst)): ?> hidden <?php endif; ?>>
        <?php echo $__env->make('customer.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main>
            <?php echo $__env->make('customer.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <section class="menu-section" id="menu" aria-labelledby="menu-title">
                <div class="wrap">
                    <div class="section-head reveal">
                        <h2 id="menu-title">Menu</h2>
                    </div>
                    <div id="menu-region"></div>
                </div>
            </section>
            <?php echo $__env->make('customer.how', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </main>
        <?php echo $__env->make('customer.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div id="cart-region"></div>
    </div>
    
    <div id="root" <?php if($customerFirst): ?> hidden <?php endif; ?>>
        <?php if (! ($customerFirst)): ?>
            <p class="state-msg wrap" role="status">Memuat…</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\nusantara-app\resources\views/home.blade.php ENDPATH**/ ?>